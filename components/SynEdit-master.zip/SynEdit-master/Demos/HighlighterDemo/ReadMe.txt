HighlighterDemo.dpr
-------------------

- Needs Delphi 2 or higher
- Shows how to create your own highlighter using a grammar file and the SynGen
  utility.
